#include "MyGameParser.hpp"
#include <iostream>

namespace sevens {

void MyGameParser::read_game(const std::string& /*filename*/) {
    // TODO: e.g., set table_layout[suit][rank] = (rank == 7) for the start of Sevens
    std::cout << "[MyGameParser::read_game] TODO: set up the table.\n";
}

} // namespace sevens
